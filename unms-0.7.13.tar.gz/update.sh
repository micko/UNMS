#!/usr/bin/env bash
set -o nounset
set -o errexit
set -o pipefail

branch="##BRANCH##" # branch name will be set by install script
homeDir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
requestUpdateFile="${homeDir}/data/update/request-update"
updateLogFile="${homeDir}/data/update/update.log"
lastUpdateFile="${homeDir}/data/update/last-update"
tmpDir="${homeDir}/tmp"
installScript="${tmpDir}/unms_install.sh"
installScriptUrl="https://raw.githubusercontent.com/Ubiquiti-App/UNMS/${branch}/install.sh"

date > "${lastUpdateFile}"

if [ -f "${requestUpdateFile}" ]; then
  exec > ${updateLogFile} 2>&1

  echo "$(date) Updating UNMS..."

  if ! rm -f "${requestUpdateFile}"; then
    echo "$(date) Failed to remove update request file"
    exit 1
  fi

  if ! mkdir -p "${tmpDir}"; then
    echo "$(date) Failed to create temp dir ${tmpDir}"
    exit 1
  fi

  if ! curl -fsSL "${installScriptUrl}" > "${installScript}"; then
    echo "$(date) Failed to download install script"
    exit 1
  fi

  chmod +x "${installScript}"
  if ! "${installScript}" --unattended; then
    echo "$(date) UNMS install script failed"
    exit 1
  fi

  rm -rf "${tmpDir}"

  echo "$(date) UNMS update finished"
  exit 0
fi

echo "UNMS update not requested."
exit 0
