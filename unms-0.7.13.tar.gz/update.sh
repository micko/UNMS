#!/usr/bin/env bash
set -o nounset
set -o errexit
set -o pipefail

branch="##BRANCH##" # branch name will be set by install script
homeDir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
requestUpdateFile="${homeDir}/data/update/request-update"
updateLogFile="${homeDir}/data/update/update.log"
lastUpdateFile="${homeDir}/data/update/last-update"
tmpDir="${homeDir}/tmp"
installScript="${tmpDir}/unms_install.sh"
installScriptUrl="https://raw.githubusercontent.com/Ubiquiti-App/UNMS/${branch}/install.sh"
rollbackDir = "${home}/rollback"

# update the update daemon's last activity timestamp
date +%s > "${lastUpdateFile}"

# check if UNMS requested an update
if [ -f "${requestUpdateFile}" ]; then
  exec > ${updateLogFile} 2>&1

  echo "$(date) Updating UNMS..."

  # remove the update request file
  if ! rm -f "${requestUpdateFile}"; then
    echo "$(date) Failed to remove update request file"
    exit 1
  fi

  # create temporary directory to download new installation files
  rm -rf "${tmpDir}"
  if ! mkdir -p "${tmpDir}"; then
    echo "$(date) Failed to create temp dir ${tmpDir}"
    exit 1
  fi

  # download install script
  if ! curl -fsSL "${installScriptUrl}" > "${installScript}"; then
    echo "$(date) Failed to download install script"
    exit 1
  fi

  # backup files necessary for rollback
  rm -rf "${rollbackDir}"
  mkdir -p "${rollbackDir}"
  if ! cp -r "${appDir}/." "${rollbackDir}/"; then
    echo "Failed to backup configuration"
    exit 1
  fi

  # run installation
  success=true
  chmod +x "${installScript}"
  if ! "${installScript}" --unattended --branch "${branch}"; then
    echo "UNMS install script failed. Attempting rollback..."

    mv -f "${rollbackDir}/unms.conf" "${appDir}/unms.conf"

    if ! "${rollbackDir}/install-full.sh" --unattended; then
      echo "Rollback failed"
    else
      echo "Rollback successful"
    fi
    success=false
  fi

  # remove temporary directories
  rm -rf "${tmpDir}"
  rm -rf "${rollbackDir}"

  if [ "$success" = true ]; then
    echo "$(date) UNMS update finished"
    exit 0
  else
    echo "$(date) UNMS update failed"
    exit 1
  fi
fi

echo "UNMS update not requested."
exit 0




rollback() {
  if [ ! -d "${PREVIOUS_PACKAGE}" ]; then
    echo "Previous version package not found - cannot rollback."
    exit 1
  fi

  rm -rf "${CURRENT_PACKAGE}"
  if ! mv "${PREVIOUS_PACKAGE}" "${CURRENT_PACKAGE}"; then
    echo "Failed to restore previous installation package - rollback failed."
    exit 1
  fi

  echo "Starting rollback..."
  if ! "${CURRENT_PACKAGE}/install-full.sh"; then
    echo "Rollback failed"
    exit 1
  fi

  echo "Rollback finished"
  exit 1
}

confirm_success_or_rollback() {
  echo "Waiting for UNMS to start"
  n=0
  until [ ${n} -ge 6 ]
  do
    unmsRunning=true
    nc -z 127.0.0.1 "${HTTPS_PORT}" && break
    echo "."
    unmsRunning=false
    n=$((n+1))
    sleep 5s
  done

  if [ "${unmsRunning}" = true ]; then
    echo "UNMS is running"
  else
    echo "UNMS is NOT running"
    rollback
  fi
}
